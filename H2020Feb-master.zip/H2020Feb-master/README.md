Design Patterns training in Feb 2020
